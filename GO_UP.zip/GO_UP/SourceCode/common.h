#ifndef COMMON_H
#define COMMON_H
#define SCREEN_W 1280
#define SCREEN_H 720
#define BLOCK_MAX 16
#endif // !COMMON_H

