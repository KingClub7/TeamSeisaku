#ifndef TEST_H
#define TEST_H
void test_init();
void test_deinit();
void test_update();
void test_render();
void judge();
void move_x();
#endif // !TEST_H
