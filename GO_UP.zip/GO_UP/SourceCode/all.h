#ifndef ALL_H
#define ALL_H
#include<stdio.h>
#include<iostream>
#include "../GameLib/game_lib.h"
#include "common.h"
#include "obj2d.h"
#include "block.h"
#include<cstring>

#include "test.h"
using namespace GameLib;
using namespace std;
using namespace input;
#endif // !ALL_H

