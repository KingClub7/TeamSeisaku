#ifndef BLOCK_H
#define BLOCK_H
class BLOCK
{
public:
	void Block_render();
};
#endif // !BLOCK_H
